package pirateGameRoom;

import org.json.* ;
import org.restlet.representation.* ;
import org.restlet.ext.json.* ;
import org.restlet.resource.* ;

public class PirateGameRoomResource extends ServerResource{

	 @Get
	    public Representation get() throws JSONException {

	      

	        JSONObject json = new JSONObject() ;
	        json.put( "pplayer", "1" ) ;
	        json.put( "stage", "0" ) ;
	        json.put( "life", "5" ) ;

	        return new JsonRepresentation ( json ) ;
	    }


	    @Post
	    public Representation post(JsonRepresentation jsonRep) {

	        JSONObject json = jsonRep.getJsonObject() ;
	        String stage = json.getString("stage") ;
	        System.out.println( "satge: " + stage ) ;

	      
	        JSONObject response = new JSONObject() ;
	        response.put("player", "1");
	        response.put( "result", stage ) ;

	        return new JsonRepresentation ( response ) ;

	    }
}
