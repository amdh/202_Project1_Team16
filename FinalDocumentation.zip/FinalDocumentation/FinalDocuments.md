This folder will contain all the documentation to be submitted in final project report and presentation
